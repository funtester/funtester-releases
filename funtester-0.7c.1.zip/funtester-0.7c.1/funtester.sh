﻿#!/bin/bash
java -jar funtester.jar